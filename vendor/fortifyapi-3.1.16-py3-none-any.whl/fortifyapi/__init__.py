__version__ = '3.1.16'

from fortifyapi.client import *
from fortifyapi.query import Query

__all__ = ['FortifySSCAPI', 'FortifySSCClient', 'Query', 'fortify', '__version__']
